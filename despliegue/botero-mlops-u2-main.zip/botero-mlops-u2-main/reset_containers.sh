docker stop flask-container
docker stop fastapi-container

docker rm flask-container
docker rm fastapi-container 
